Comp 3004 

Final Project

Implementing a tandem pump simulation

Team 37


Devanjali Das

Karan Modi

Zainab Jahangir

Gurleen Bassali


Description Of the Submission File:

File Name: Comp_3004_Final_Project:

-> Diagrams : 
   |
   |-> State Machine Diagram: State_Machine_diagram_01 ( Insulin Pump State Machine Diagram), State_machine_dagram_02 ( Control IQ state Machine Diagram),          
(Bolus_Calculation_State_macine_Diagram)
   |
   |-> Sequence Diagram : (There are all together 7 sequence Diagrams) ( Sequence Diagram Names: 
   |
        
->QT Code Files: 

-> Use_Cases.pdf



Simulation  Video Links :
